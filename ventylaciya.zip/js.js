<!doctype html>
<html lang="ru-RU">
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="profile" href="../https@gmpg.org/xfn/11">

		<title>Страница не найдена &#8212; Expert Project</title>
<meta name='robots' content='max-image-preview:large' />

<!-- Google Tag Manager for WordPress by gtm4wp.com -->
<script data-cfasync="false" data-pagespeed-no-defer type="text/javascript">
	var gtm4wp_datalayer_name = "dataLayer";
	var dataLayer = dataLayer || [];
</script>
<!-- End Google Tag Manager for WordPress by gtm4wp.com --><link rel='dns-prefetch' href='../https@code.jquery.com/default.htm' />
<link rel='dns-prefetch' href='../https@unpkg.com/default.htm' />
<link rel='dns-prefetch' href='../https@s.w.org/default.htm' />
<link rel="alternate" type="application/rss+xml" title="Expert Project &raquo; Лента" href="feed/default.htm" />
<link rel="alternate" type="application/rss+xml" title="Expert Project &raquo; Лента комментариев" href="comments/feed/default.htm" />
<script>
window._wpemojiSettings = {"baseUrl":"../https@s.w.org/images/core/emoji/14.0.0/72x72/","ext":".png","svgUrl":"../https@s.w.org/images/core/emoji/14.0.0/svg/default.htm","svgExt":".svg","source":{"concatemoji":"wp-includes/js/wp-emoji-release.min.js@ver=6.0.1"}};
/*! This file is auto-generated */
!function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode,e=(p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0),i.toDataURL());return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(!p||!p.fillText)return!1;switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])?!1:!s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([129777,127995,8205,129778,127999],[129777,127995,8203,129778,127999])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(e=t.source||{}).concatemoji?c(e.concatemoji):e.wpemoji&&e.twemoji&&(c(e.twemoji),c(e.wpemoji)))}(window,document,window._wpemojiSettings);
</script>
<style>
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 0.07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='wp-block-library-css'  href='wp-includes/css/dist/block-library/style.min.css@ver=6.0.1' media='all' />
<style id='global-styles-inline-css'>
body{--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--duotone--dark-grayscale: url('#wp-duotone-dark-grayscale');--wp--preset--duotone--grayscale: url('#wp-duotone-grayscale');--wp--preset--duotone--purple-yellow: url('#wp-duotone-purple-yellow');--wp--preset--duotone--blue-red: url('#wp-duotone-blue-red');--wp--preset--duotone--midnight: url('#wp-duotone-midnight');--wp--preset--duotone--magenta-yellow: url('#wp-duotone-magenta-yellow');--wp--preset--duotone--purple-green: url('#wp-duotone-purple-green');--wp--preset--duotone--blue-orange: url('#wp-duotone-blue-orange');--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
</style>
<link rel='stylesheet' id='contact-form-7-css'  href='wp-content/plugins/contact-form-7/includes/css/styles.css@ver=5.5.6.1' media='all' />
<link rel='stylesheet' id='style-reset-css'  href='wp-content/themes/impulsedesign/css/reset.css@ver=6.0.1' media='all' />
<link rel='stylesheet' id='style-animate-css'  href='wp-content/themes/impulsedesign/css/animate.css@ver=6.0.1' media='all' />
<link rel='stylesheet' id='style-swiper-css'  href='../https@unpkg.com/swiper/swiper-bundle.min.css@ver=6.0.1' media='all' />
<link rel='stylesheet' id='impulsedesign-style-css'  href='wp-content/themes/impulsedesign/style.css@ver=1.0.0' media='all' />
<link rel="https://api.w.org/" href="wp-json/default.htm" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://expert-project.com.ua/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 6.0.1" />

<!-- Google Tag Manager for WordPress by gtm4wp.com -->
<!-- GTM Container placement set to footer -->
<script data-cfasync="false" data-pagespeed-no-defer type="text/javascript">
	var dataLayer_content = {"pagePostType":"404-error"};
	dataLayer.push( dataLayer_content );
</script>
<script data-cfasync="false">
(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'../https@www.googletagmanager.com/gtm.'+'js@id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-W444WC7');
</script>
<!-- End Google Tag Manager -->
<!-- End Google Tag Manager for WordPress by gtm4wp.com --><link rel="icon" href="wp-content/uploads/2022/06/label-wrap.svg" sizes="32x32" />
<link rel="icon" href="wp-content/uploads/2022/06/label-wrap.svg" sizes="192x192" />
<link rel="apple-touch-icon" href="wp-content/uploads/2022/06/label-wrap.svg" />
<meta name="msapplication-TileImage" content="https://expert-project.com.ua/wp-content/uploads/2022/06/label-wrap.svg" />
		
<!-- Meta Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'../https@connect.facebook.net/en_US/fbevents.js');
fbq('init', '717021639531126');
fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
src="../https@www.facebook.com/tr@id=717021639531126&ev=PageView&noscript=1"
/></noscript>
<!-- End Meta Pixel Code -->

<meta name="facebook-domain-verification" content="vtdbuefgj3y70gde76ifxbmrgy9ny8" />
<meta name="google-site-verification" content="Pog7e7v80R1TemrmYiZ93LXE4f3RcSgrXvoO6zWbb54" />		
	</head>

	<body class="error404 wp-custom-logo hfeed">
		<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;" ><defs><filter id="wp-duotone-dark-grayscale"><feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " /><feComponentTransfer color-interpolation-filters="sRGB" ><feFuncR type="table" tableValues="0 0.49803921568627" /><feFuncG type="table" tableValues="0 0.49803921568627" /><feFuncB type="table" tableValues="0 0.49803921568627" /><feFuncA type="table" tableValues="1 1" /></feComponentTransfer><feComposite in2="SourceGraphic" operator="in" /></filter></defs></svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;" ><defs><filter id="wp-duotone-grayscale"><feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " /><feComponentTransfer color-interpolation-filters="sRGB" ><feFuncR type="table" tableValues="0 1" /><feFuncG type="table" tableValues="0 1" /><feFuncB type="table" tableValues="0 1" /><feFuncA type="table" tableValues="1 1" /></feComponentTransfer><feComposite in2="SourceGraphic" operator="in" /></filter></defs></svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;" ><defs><filter id="wp-duotone-purple-yellow"><feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " /><feComponentTransfer color-interpolation-filters="sRGB" ><feFuncR type="table" tableValues="0.54901960784314 0.98823529411765" /><feFuncG type="table" tableValues="0 1" /><feFuncB type="table" tableValues="0.71764705882353 0.25490196078431" /><feFuncA type="table" tableValues="1 1" /></feComponentTransfer><feComposite in2="SourceGraphic" operator="in" /></filter></defs></svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;" ><defs><filter id="wp-duotone-blue-red"><feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " /><feComponentTransfer color-interpolation-filters="sRGB" ><feFuncR type="table" tableValues="0 1" /><feFuncG type="table" tableValues="0 0.27843137254902" /><feFuncB type="table" tableValues="0.5921568627451 0.27843137254902" /><feFuncA type="table" tableValues="1 1" /></feComponentTransfer><feComposite in2="SourceGraphic" operator="in" /></filter></defs></svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;" ><defs><filter id="wp-duotone-midnight"><feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " /><feComponentTransfer color-interpolation-filters="sRGB" ><feFuncR type="table" tableValues="0 0" /><feFuncG type="table" tableValues="0 0.64705882352941" /><feFuncB type="table" tableValues="0 1" /><feFuncA type="table" tableValues="1 1" /></feComponentTransfer><feComposite in2="SourceGraphic" operator="in" /></filter></defs></svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;" ><defs><filter id="wp-duotone-magenta-yellow"><feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " /><feComponentTransfer color-interpolation-filters="sRGB" ><feFuncR type="table" tableValues="0.78039215686275 1" /><feFuncG type="table" tableValues="0 0.94901960784314" /><feFuncB type="table" tableValues="0.35294117647059 0.47058823529412" /><feFuncA type="table" tableValues="1 1" /></feComponentTransfer><feComposite in2="SourceGraphic" operator="in" /></filter></defs></svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;" ><defs><filter id="wp-duotone-purple-green"><feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " /><feComponentTransfer color-interpolation-filters="sRGB" ><feFuncR type="table" tableValues="0.65098039215686 0.40392156862745" /><feFuncG type="table" tableValues="0 1" /><feFuncB type="table" tableValues="0.44705882352941 0.4" /><feFuncA type="table" tableValues="1 1" /></feComponentTransfer><feComposite in2="SourceGraphic" operator="in" /></filter></defs></svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;" ><defs><filter id="wp-duotone-blue-orange"><feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " /><feComponentTransfer color-interpolation-filters="sRGB" ><feFuncR type="table" tableValues="0.098039215686275 1" /><feFuncG type="table" tableValues="0 0.66274509803922" /><feFuncB type="table" tableValues="0.84705882352941 0.41960784313725" /><feFuncA type="table" tableValues="1 1" /></feComponentTransfer><feComposite in2="SourceGraphic" operator="in" /></filter></defs></svg>
		<a id="btn-to-top">
			<svg width="17" height="27" viewBox="0 0 17 27" fill="none" xmlns="http://www.w3.org/2000/svg">
				<path d="M0.992188 12.8125C0.464844 13.3398 0.464844 14.2188 0.992188 14.7461L12.3594 26.1719C12.9453 26.6992 13.8242 26.6992 14.3516 26.1719L15.6992 24.8242C16.2266 24.2969 16.2266 23.418 15.6992 22.832L6.67578 13.75L15.6992 4.72656C16.2266 4.14062 16.2266 3.26172 15.6992 2.73438L14.3516 1.38672C13.8242 0.859375 12.9453 0.859375 12.3594 1.38672L0.992188 12.8125Z" fill="#fff"/>
			</svg>
		</a>

		<header class="header">
			<div class="_container">
				<div class="header__wrapper">
					<div class="header__logo">
						<a href="default.htm" class="custom-logo-link" rel="home"><img width="181" height="106" src="wp-content/uploads/2022/06/logo.svg" class="custom-logo" alt="Expert Project" /></a>					</div>
					<div class="header__tagline">
						<p>Інженерні системи будь-якої <span></span>складності під ключ</p>
					</div>

					<div class="contacts">
						<div class="contacts__list">
							<div class="header__logo__mob">
								<a href="default.htm" class="custom-logo-link" rel="home"><img width="181" height="106" src="wp-content/uploads/2022/06/logo.svg" class="custom-logo" alt="Expert Project" /></a>								<div class="contacts__close__list">
								</div>
							</div>
							<div class="header__tagline__mob">
								<p>Інженерні системи будь-якої <span></span>складності під ключ</p>
							</div>
							<div class="contacts__numbers">
								<a href="tel_3A+38 096 169 5775" class="contacts__tel">+38 096 169 5775</a>
								<a href="tel_3A+38 073 169 5775" class="contacts__tel">+38 073 169 5775</a>
							</div>

							<div class="contacts__socials">
								<a href="viber_3A//chat@number=0961695775" class="contacts__messenger">
									<svg width="28" height="29" viewBox="0 0 28 29" fill="none" xmlns="http://www.w3.org/2000/svg">
										<path d="M24.2629 3.25078C23.5525 2.64967 20.7109 0.573115 14.4813 0.573115C14.4813 0.573115 7.10402 0.135944 3.49736 3.41472C1.47545 5.43663 0.765048 8.33289 0.710402 11.9942C0.655755 15.6008 0.546463 22.4316 7.10402 24.2896V27.0766C7.10402 27.0766 7.04937 28.2241 7.81442 28.4974C8.7434 28.7706 9.23522 27.8963 10.1096 26.9673C10.6014 26.4208 11.2571 25.7104 11.7489 25.1093C16.2299 25.4918 19.6727 24.6175 20.1098 24.5082C20.9842 24.1803 26.1209 23.5246 26.9406 16.7484C27.815 9.69904 26.5581 5.27269 24.2629 3.25078ZM24.9733 16.2019C24.3176 21.8852 20.1098 22.2677 19.3448 22.5409C19.0169 22.5956 16.0114 23.3606 12.1861 23.142C12.1861 23.142 9.34451 26.5301 8.47017 27.4591C8.19694 27.7323 7.86906 27.7323 7.86906 27.1312C7.86906 26.7487 7.86906 22.4316 7.86906 22.4316C2.34979 20.9015 2.67767 15.109 2.73231 12.1035C2.78696 9.04329 3.33342 6.58421 5.02746 4.89017C8.08765 2.10321 14.372 2.54038 14.372 2.54038C19.6727 2.54038 22.1864 4.17977 22.7875 4.67159C24.7548 6.36562 25.7384 10.3548 24.9733 16.2019ZM17.3775 11.8302C17.3229 10.2455 16.5032 9.37117 14.9731 9.26187C14.4813 9.26187 14.4266 9.97227 14.9184 9.97227C16.066 10.0816 16.6125 10.628 16.7218 11.8302C16.7218 12.3221 17.4322 12.2674 17.3775 11.8302ZM18.5251 12.4314C18.5251 12.8685 19.2355 12.9232 19.2355 12.4314C19.2901 9.80834 17.5961 7.62248 14.4266 7.4039C13.9348 7.34925 13.8802 8.05965 14.372 8.1143C17.1043 8.27824 18.5797 10.1362 18.5251 12.4314ZM21.0935 13.1418C21.0388 8.38753 17.8147 5.60057 13.7709 5.54593C13.3337 5.54593 13.3337 6.25633 13.7709 6.25633C17.3775 6.31097 20.3284 8.71541 20.3831 13.1418C20.3831 13.6336 21.0935 13.6336 21.0935 13.1418ZM20.4377 18.4971C20.7109 18.0053 20.6563 17.5681 20.2738 17.2402C19.5634 16.5845 18.5797 15.8741 17.76 15.4369C17.1589 15.109 16.5578 15.3276 16.2846 15.6555L15.7928 16.3112C15.5195 16.6391 15.0277 16.5845 15.0277 16.5845C11.3664 15.6555 10.3828 11.9942 10.3828 11.9942C10.3828 11.9942 10.3828 11.5024 10.7107 11.2291L11.3664 10.6827C11.6943 10.4094 11.8582 9.80834 11.5304 9.20723C11.3664 8.87935 10.9839 8.27824 10.7107 7.95036C10.4374 7.51319 9.72704 6.74814 9.72704 6.74814C9.45381 6.31097 8.96199 6.25633 8.47017 6.52956H8.41553C7.37725 7.07602 6.22968 8.22359 6.6122 9.31652C6.6122 9.31652 6.88543 10.3002 8.033 12.3767C8.57947 13.415 9.18057 14.2347 9.72704 14.9451C10.3281 15.7101 11.1478 16.5298 12.0222 17.2402C13.7709 18.6064 16.4485 20.0272 17.5961 20.3551H17.6507C18.7437 20.7376 19.8912 19.59 20.4377 18.5517V18.4971Z" fill="#1D1D1D"/>
									</svg>
								</a>
								<a href="whatsapp_3A//send@phone=+380961695775" class="contacts__messenger">
									<svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
										<path d="M20.7656 3.8738C18.5251 1.57866 15.4649 0.267149 12.1861 0.267149C5.51927 0.267149 0.0546463 5.73178 0.0546463 12.3986C0.0546463 14.5845 0.655755 16.661 1.69403 18.4644L0 24.7487L6.39361 23.1093C8.19694 24.0383 10.1642 24.5847 12.1861 24.5847C18.9076 24.5847 24.4815 19.1201 24.4815 12.4533C24.4815 9.17449 23.0607 6.16895 20.7656 3.8738ZM12.1861 22.5082C10.3828 22.5082 8.63411 22.0164 7.04937 21.0874L6.72149 20.8688L2.89625 21.9071L3.93453 18.1911L3.6613 17.8086C2.67767 16.1692 2.1312 14.3112 2.1312 12.3986C2.1312 6.87935 6.66685 2.34371 12.2408 2.34371C14.9184 2.34371 17.4322 3.38199 19.3448 5.29461C21.2574 7.20723 22.405 9.72095 22.405 12.4533C22.405 17.9725 17.76 22.5082 12.1861 22.5082ZM17.76 14.967C17.4322 14.8031 15.9567 14.0927 15.6835 13.9834C15.4102 13.8741 15.1917 13.8194 14.9731 14.1473C14.8091 14.4205 14.208 15.1309 14.0441 15.3495C13.8255 15.5135 13.6616 15.5681 13.3883 15.4042C11.585 14.5298 10.4374 13.8194 9.23522 11.7975C8.90734 11.2511 9.5631 11.3057 10.1096 10.1581C10.2189 9.93954 10.1642 9.7756 10.1096 9.61166C10.0549 9.44772 9.39916 7.97227 9.18057 7.37117C8.90734 6.77006 8.68876 6.8247 8.47017 6.8247C8.30623 6.8247 8.08765 6.8247 7.92371 6.8247C7.70512 6.8247 7.37725 6.87935 7.10402 7.20723C6.83078 7.5351 6.06574 8.24551 6.06574 9.72095C6.06574 11.2511 7.10402 12.6719 7.26795 12.8904C7.43189 13.0544 9.39916 16.1146 12.4594 17.4261C14.372 18.3004 15.137 18.3551 16.1207 18.1911C16.6671 18.1365 17.8693 17.4807 18.1426 16.7703C18.4158 16.0599 18.4158 15.4588 18.3065 15.3495C18.2519 15.1856 18.0333 15.1309 17.76 14.967Z" fill="#1D1D1D"/>
									</svg>
								</a>
								<a href="tg_3A//resolve@domain=expertprojectua" class="contacts__messenger">
									<svg width="26" height="22" viewBox="0 0 26 22" fill="none" xmlns="http://www.w3.org/2000/svg">
										<path d="M25.3722 2.92845C25.7001 1.39835 24.8258 0.797245 23.8421 1.17977L2.09293 9.54065C0.617476 10.1418 0.672122 10.9615 1.87434 11.344L7.39361 13.038L20.2901 4.95036C20.8912 4.51319 21.4924 4.78642 21.0005 5.16895L10.5631 14.5681L10.1806 20.306C10.7817 20.306 11.0003 20.0874 11.3281 19.7595L14.0058 17.1365L19.6344 21.2896C20.6727 21.8907 21.4377 21.5628 21.7109 20.3606L25.3722 2.92845Z" fill="#1D1D1D"/>
									</svg>
								</a>
							</div>



						</div>

						<div class="contacts__toggle">
							<svg height="25px" viewBox="0 0 48 48" width="25px" xmlns="http://www.w3.org/2000/svg">
								<path d="M0 0h48v48h-48z" fill="none"></path>
								<path  fill="#144279" d="M13.25 21.59c2.88 5.66 7.51 10.29 13.18 13.17l4.4-4.41c.55-.55 1.34-.71 2.03-.49 2.24.74 4.65 1.14 7.14 1.14 1.11 0 2 .89 2 2v7c0 1.11-.89 2-2 2-18.78 0-34-15.22-34-34 0-1.11.9-2 2-2h7c1.11 0 2 .89 2 2 0 2.49.4 4.9 1.14 7.14.22.69.06 1.48-.49 2.03l-4.4 4.42z"></path>'
							</svg>
						</div>
					</div>
				</div>
			</div>
		</header>

<section class="thanks">
	<div class="_container">
		<div class="thanks__wrapper">
			<p class="title thanks__title wow fadeInUp" data-wow-duration=".3s" data-wow-delay=".1s">
				404
			</p>
			<p class="subtitle thanks__subtitle wow fadeInUp" data-wow-duration=".3s" data-wow-delay=".3s">
				Сторінка, яку Ви шукаєте, не існує або застаріла.
			</p>
			<a href="default.htm" class="_btn thanks__btn wow fadeInUp" data-wow-duration=".3s" data-wow-delay=".3s">На головну</a>
		</div>

		<div class="thanks__bg skrollable skrollable-between" data-top-bottom="transform: translateY(50px);" data-bottom-top="transform: translateY(-50px);">
			<img src="wp-content/uploads/2022/06/bg-audit.png" alt="audit">
		</div>
	</div>
</section>


<footer class="footer">
	<div class="_container">
		<div class="footer__wrapper">
			<div class="footer__logo">
				<a href="default.htm" class="custom-logo-link">
					<svg class="logo" width="180" height="97" viewBox="0 0 180 97" fill="none" xmlns="http://www.w3.org/2000/svg">
						<g clip-path="url(#clip0_64_445)">
							<path fill-rule="evenodd" clip-rule="evenodd" d="M79.1338 0L84.197 2.19113V19.9324L79.1338 22.1236V0Z" fill="#00AFEF"/>
							<path fill-rule="evenodd" clip-rule="evenodd" d="M76.9876 37.1394L71.9243 34.9482V53.1209L76.8362 55.9557L76.9876 56.0516V37.1394Z" fill="white"/>
							<path fill-rule="evenodd" clip-rule="evenodd" d="M107.394 34.0574L102.331 31.8594V56.1535L102.482 56.0782L107.394 53.2503V34.0574Z" fill="#00AFEF"/>
							<path fill-rule="evenodd" clip-rule="evenodd" d="M99.6414 24.7595L94.5781 22.5684V34.0307L99.6414 31.8396V24.7595Z" fill="#00AFEF"/>
							<path fill-rule="evenodd" clip-rule="evenodd" d="M85.3735 64.495V20.9052L90.4368 23.0963V66.5081L102.483 59.5992L115.292 52.2041V22.7128L102.483 15.3178L89.6663 7.95695L87.5199 9.17576V3.34188L89.6663 2.11621L105.014 10.9629L120.355 19.7822V55.1416L105.014 63.9609L89.6663 72.8007L74.2976 63.9609L58.9565 55.1416V19.7822L74.2976 10.9629L75.8318 10.0728V15.9066L64.0198 22.7128V52.2041L76.8362 59.5992L85.3735 64.495Z" fill="white"/>
							<path d="M3.83872 93.3429H8.65431V96.0818H0V82.0586H8.44105V84.7975H3.83872V87.6597H7.80126V90.3986H3.83872V93.3429Z" fill="white"/>
							<path d="M19.7991 88.9538L23.4589 96.0681H19.1387L17.6252 92.1378L16.1117 96.0681H12.0322L15.4719 88.9538L12.1148 82.0586H16.4557L17.6183 85.6397L18.8016 82.0586H22.9292L19.7991 88.9538Z" fill="white"/>
							<path d="M27.4009 82.0586H33.9157C36.0621 82.0586 37.1353 82.9602 37.1353 84.7633V88.7826C37.1353 90.5812 36.0621 91.4827 33.9157 91.4873H31.2396V96.0681H27.4009V82.0586ZM33.2965 88.2759V85.27C33.2965 84.9481 33.1177 84.7838 32.7531 84.7838H31.2396V88.7552H32.7531C33.1177 88.7552 33.2965 88.5977 33.2965 88.2759Z" fill="white"/>
							<path d="M45.3558 93.3429H50.1714V96.0818H41.5171V82.0586H49.9581V84.7975H45.3558V87.6597H49.3252V90.3986H45.3558V93.3429Z" fill="white"/>
							<path d="M58.2689 91.0902V96.0681H54.4302V82.0586H60.945C63.0914 82.0586 64.1646 82.9602 64.1646 84.7633V88.3855C64.2274 88.9686 64.0689 89.554 63.7201 90.0266C63.3713 90.4993 62.8574 90.8249 62.2796 90.9395L64.8663 96.0681H60.7386L58.5028 91.0902H58.2689ZM59.7824 84.7838H58.2689V88.495H59.7824C60.147 88.495 60.3258 88.3376 60.3258 88.0157V85.2768C60.3258 84.9481 60.147 84.7838 59.7824 84.7838Z" fill="white"/>
							<path d="M77.2558 82.0576V84.7966H74.504V96.0809H70.6721V84.7829H68.0029V82.0439L77.2558 82.0576Z" fill="white"/>
							<path d="M88.7446 82.0586H95.2594C97.4058 82.0586 98.479 82.9602 98.479 84.7633V88.7826C98.479 90.5812 97.4058 91.4827 95.2594 91.4873H92.5971V96.0681H88.7446V82.0586ZM94.6472 88.2759V85.27C94.6472 84.9481 94.4614 84.7838 94.0968 84.7838H92.5833V88.7552H94.0968C94.4752 88.7552 94.6609 88.5977 94.6609 88.2759H94.6472Z" fill="white"/>
							<path d="M106.714 91.0902V96.0681H102.875V82.0586H109.383C111.529 82.0586 112.602 82.9602 112.602 84.7633V88.3855C112.665 88.9686 112.507 89.554 112.158 90.0266C111.809 90.4993 111.295 90.8249 110.718 90.9395L113.304 96.0681H109.177L106.941 91.0902H106.714ZM108.227 84.7838H106.714V88.495H108.227C108.592 88.495 108.778 88.3376 108.778 88.0157V85.2768C108.778 84.9481 108.592 84.7838 108.227 84.7838Z" fill="white"/>
							<path d="M120.39 82.0586H123.637C125.784 82.0586 126.864 82.9624 126.864 84.7633V93.3635C126.864 95.1643 125.784 96.0681 123.637 96.0681H120.39C118.244 96.0681 117.171 95.1666 117.171 93.3635V84.7633C117.157 82.9647 118.23 82.0632 120.39 82.0586ZM123.025 92.8636V85.27C123.025 84.9481 122.839 84.7838 122.475 84.7838H121.553C121.188 84.7838 121.009 84.9481 121.009 85.27V92.8636C121.009 93.1786 121.188 93.3429 121.553 93.3429H122.454C122.819 93.3429 123.004 93.1786 123.004 92.8636H123.025Z" fill="white"/>
							<path d="M130.936 90.4944H134.775V92.8978C134.775 93.2128 134.961 93.3772 135.325 93.3772H135.566C135.931 93.3772 136.109 93.2128 136.109 92.8978V82.0586H139.948V93.3635C139.948 95.162 138.875 96.0636 136.729 96.0681H134.149C131.993 96.0681 130.918 95.1666 130.922 93.3635L130.936 90.4944Z" fill="white"/>
							<path d="M148.52 93.3429H153.335V96.0818H144.681V82.0586H153.122V84.7975H148.52V87.6597H152.489V90.3986H148.52V93.3429Z" fill="white"/>
							<path d="M167.025 87.2968H163.186V85.0509C163.186 84.729 163.001 84.5715 162.636 84.5715H161.872C161.508 84.5715 161.322 84.729 161.322 85.0509V93.0759C161.322 93.3977 161.508 93.562 161.872 93.562H162.636C163.001 93.562 163.186 93.3977 163.186 93.0759V90.919H167.025V93.3635C167.025 95.1643 165.945 96.0681 163.799 96.0681H160.71C158.554 96.0681 157.479 95.1666 157.483 93.3635V84.7633C157.483 82.9647 158.559 82.0632 160.71 82.0586H163.799C165.945 82.0586 167.025 82.9624 167.025 84.7633V87.2968Z" fill="white"/>
							<path d="M180 82.0576V84.7966H177.283V96.0809H173.444V84.7829H170.747V82.0439L180 82.0576Z" fill="white"/>
						</g>
						<defs>
							<clipPath id="clip0_64_445">
								<rect width="180" height="96.0674" fill="white"/>
							</clipPath>
						</defs>
					</svg>
				</a>
			</div>
			<div class="footer-contacts">
				<div class="footer-contacts__numbers">
					<a href="tel_3A+38 096 169 5775" class="footer-contacts__tel">+38 096 169 5775</a>
					<a href="tel_3A+38 073 169 5775" class="footer-contacts__tel">+38 073 169 5775</a>
				</div>
				<div class="footer-contacts__adress">
					<a href="../https@goo.gl/maps/RKwThE6NCxZhaF8DA" target="_blank" rel="nofollow noopener">02094, м. Київ, вул. Пожарського, 4</a>
					<a href="mailto:info@expert-project.com.ua">info@expert-project.com.ua</a>
				</div>
				<div class="footer-contacts__socials">
					<a href="viber_3A//chat@number=0961695775" class="footer-contacts__messenger">
						<svg width="28" height="29" viewBox="0 0 28 29" fill="none" xmlns="http://www.w3.org/2000/svg">
							<path d="M24.2629 3.25078C23.5525 2.64967 20.7109 0.573115 14.4813 0.573115C14.4813 0.573115 7.10402 0.135944 3.49736 3.41472C1.47545 5.43663 0.765048 8.33289 0.710402 11.9942C0.655755 15.6008 0.546463 22.4316 7.10402 24.2896V27.0766C7.10402 27.0766 7.04937 28.2241 7.81442 28.4974C8.7434 28.7706 9.23522 27.8963 10.1096 26.9673C10.6014 26.4208 11.2571 25.7104 11.7489 25.1093C16.2299 25.4918 19.6727 24.6175 20.1098 24.5082C20.9842 24.1803 26.1209 23.5246 26.9406 16.7484C27.815 9.69904 26.5581 5.27269 24.2629 3.25078ZM24.9733 16.2019C24.3176 21.8852 20.1098 22.2677 19.3448 22.5409C19.0169 22.5956 16.0114 23.3606 12.1861 23.142C12.1861 23.142 9.34451 26.5301 8.47017 27.4591C8.19694 27.7323 7.86906 27.7323 7.86906 27.1312C7.86906 26.7487 7.86906 22.4316 7.86906 22.4316C2.34979 20.9015 2.67767 15.109 2.73231 12.1035C2.78696 9.04329 3.33342 6.58421 5.02746 4.89017C8.08765 2.10321 14.372 2.54038 14.372 2.54038C19.6727 2.54038 22.1864 4.17977 22.7875 4.67159C24.7548 6.36562 25.7384 10.3548 24.9733 16.2019ZM17.3775 11.8302C17.3229 10.2455 16.5032 9.37117 14.9731 9.26187C14.4813 9.26187 14.4266 9.97227 14.9184 9.97227C16.066 10.0816 16.6125 10.628 16.7218 11.8302C16.7218 12.3221 17.4322 12.2674 17.3775 11.8302ZM18.5251 12.4314C18.5251 12.8685 19.2355 12.9232 19.2355 12.4314C19.2901 9.80834 17.5961 7.62248 14.4266 7.4039C13.9348 7.34925 13.8802 8.05965 14.372 8.1143C17.1043 8.27824 18.5797 10.1362 18.5251 12.4314ZM21.0935 13.1418C21.0388 8.38753 17.8147 5.60057 13.7709 5.54593C13.3337 5.54593 13.3337 6.25633 13.7709 6.25633C17.3775 6.31097 20.3284 8.71541 20.3831 13.1418C20.3831 13.6336 21.0935 13.6336 21.0935 13.1418ZM20.4377 18.4971C20.7109 18.0053 20.6563 17.5681 20.2738 17.2402C19.5634 16.5845 18.5797 15.8741 17.76 15.4369C17.1589 15.109 16.5578 15.3276 16.2846 15.6555L15.7928 16.3112C15.5195 16.6391 15.0277 16.5845 15.0277 16.5845C11.3664 15.6555 10.3828 11.9942 10.3828 11.9942C10.3828 11.9942 10.3828 11.5024 10.7107 11.2291L11.3664 10.6827C11.6943 10.4094 11.8582 9.80834 11.5304 9.20723C11.3664 8.87935 10.9839 8.27824 10.7107 7.95036C10.4374 7.51319 9.72704 6.74814 9.72704 6.74814C9.45381 6.31097 8.96199 6.25633 8.47017 6.52956H8.41553C7.37725 7.07602 6.22968 8.22359 6.6122 9.31652C6.6122 9.31652 6.88543 10.3002 8.033 12.3767C8.57947 13.415 9.18057 14.2347 9.72704 14.9451C10.3281 15.7101 11.1478 16.5298 12.0222 17.2402C13.7709 18.6064 16.4485 20.0272 17.5961 20.3551H17.6507C18.7437 20.7376 19.8912 19.59 20.4377 18.5517V18.4971Z" fill="#1D1D1D"></path>
						</svg>
					</a>
					<a href="whatsapp_3A//send@phone=+380961695775" class="footer-contacts__messenger">
						<svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
							<path d="M20.7656 3.8738C18.5251 1.57866 15.4649 0.267149 12.1861 0.267149C5.51927 0.267149 0.0546463 5.73178 0.0546463 12.3986C0.0546463 14.5845 0.655755 16.661 1.69403 18.4644L0 24.7487L6.39361 23.1093C8.19694 24.0383 10.1642 24.5847 12.1861 24.5847C18.9076 24.5847 24.4815 19.1201 24.4815 12.4533C24.4815 9.17449 23.0607 6.16895 20.7656 3.8738ZM12.1861 22.5082C10.3828 22.5082 8.63411 22.0164 7.04937 21.0874L6.72149 20.8688L2.89625 21.9071L3.93453 18.1911L3.6613 17.8086C2.67767 16.1692 2.1312 14.3112 2.1312 12.3986C2.1312 6.87935 6.66685 2.34371 12.2408 2.34371C14.9184 2.34371 17.4322 3.38199 19.3448 5.29461C21.2574 7.20723 22.405 9.72095 22.405 12.4533C22.405 17.9725 17.76 22.5082 12.1861 22.5082ZM17.76 14.967C17.4322 14.8031 15.9567 14.0927 15.6835 13.9834C15.4102 13.8741 15.1917 13.8194 14.9731 14.1473C14.8091 14.4205 14.208 15.1309 14.0441 15.3495C13.8255 15.5135 13.6616 15.5681 13.3883 15.4042C11.585 14.5298 10.4374 13.8194 9.23522 11.7975C8.90734 11.2511 9.5631 11.3057 10.1096 10.1581C10.2189 9.93954 10.1642 9.7756 10.1096 9.61166C10.0549 9.44772 9.39916 7.97227 9.18057 7.37117C8.90734 6.77006 8.68876 6.8247 8.47017 6.8247C8.30623 6.8247 8.08765 6.8247 7.92371 6.8247C7.70512 6.8247 7.37725 6.87935 7.10402 7.20723C6.83078 7.5351 6.06574 8.24551 6.06574 9.72095C6.06574 11.2511 7.10402 12.6719 7.26795 12.8904C7.43189 13.0544 9.39916 16.1146 12.4594 17.4261C14.372 18.3004 15.137 18.3551 16.1207 18.1911C16.6671 18.1365 17.8693 17.4807 18.1426 16.7703C18.4158 16.0599 18.4158 15.4588 18.3065 15.3495C18.2519 15.1856 18.0333 15.1309 17.76 14.967Z" fill="#1D1D1D"></path>
						</svg>
					</a>
					<a href="tg_3A//resolve@domain=expertprojectua" class="footer-contacts__messenger">
						<svg width="26" height="22" viewBox="0 0 26 22" fill="none" xmlns="http://www.w3.org/2000/svg">
							<path d="M25.3722 2.92845C25.7001 1.39835 24.8258 0.797245 23.8421 1.17977L2.09293 9.54065C0.617476 10.1418 0.672122 10.9615 1.87434 11.344L7.39361 13.038L20.2901 4.95036C20.8912 4.51319 21.4924 4.78642 21.0005 5.16895L10.5631 14.5681L10.1806 20.306C10.7817 20.306 11.0003 20.0874 11.3281 19.7595L14.0058 17.1365L19.6344 21.2896C20.6727 21.8907 21.4377 21.5628 21.7109 20.3606L25.3722 2.92845Z" fill="#1D1D1D"></path>
						</svg>
					</a>
				</div>
			</div>
			<div class="footer__copyrights">
				<p>© Expert project, 2022</p>
				<a href="../https@impulse-design.com.ua/default.htm" target="_blank" rel="nofollow noopener">
					Створення та просування сайтів:
					<img src="wp-content/uploads/2022/06/impulse.png" alt="impulse">
				</a>
			</div>
		</div>
	</div>
</footer>


<!-- GTM Container placement set to footer -->
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="../https@www.googletagmanager.com/ns.html@id=GTM-W444WC7"
height="0" width="0" style="display:none;visibility:hidden" aria-hidden="true"></iframe></noscript>
<!-- End Google Tag Manager (noscript) --><script src='wp-includes/js/dist/vendor/regenerator-runtime.min.js@ver=0.13.9' id='regenerator-runtime-js'></script>
<script src='wp-includes/js/dist/vendor/wp-polyfill.min.js@ver=3.15.0' id='wp-polyfill-js'></script>
<script id='contact-form-7-js-extra'>
var wpcf7 = {"api":{"root":"wp-json/default.htm","namespace":"contact-form-7\/v1"}};
</script>
<script src='wp-content/plugins/contact-form-7/includes/js/index.js@ver=5.5.6.1' id='contact-form-7-js'></script>
<script src='../https@code.jquery.com/jquery-3.5.1.min.js@ver=1.0.0' id='jquery-js'></script>
<script src='wp-content/themes/impulsedesign/js/wow.min.js@ver=1.0.0' id='script-wow-js'></script>
<script src='wp-content/themes/impulsedesign/js/skrollr.min.js@ver=1.0.0' id='script-skrollr-js'></script>
<script src='../https@unpkg.com/swiper/swiper-bundle.min.js@ver=1.0.0' id='script-swiper-js'></script>
<script src='wp-content/themes/impulsedesign/js/script.js@ver=1.0.0' id='script-main-js'></script>
<script src='wp-content/themes/impulsedesign/js/navigation.js@ver=1.0.0' id='impulsedesign-navigation-js'></script>

</body>
</html>